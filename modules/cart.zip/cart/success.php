<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" href="/adamstore/css/success.css">
</head>
<body>
    <div class = "body-introduction">
                <div id="order-success">
                	<div class="">
                    
                        <div id="order-success-txt" class="col-lg-9 col-md-9 col-sm-12">
                            <img src="./image/img-ship.png" alt=""><br>
                        	<h3>Bạn đã đặt hàng thành công !</h3>
                            <p>Cảm ơn quý khách đã tin tưởng sản phẩm bên ADAM STORE</p>
                            <br><br>
                            <div class="button-muangay">
        
      <a href="index.php"><button>        
          <h1 style="color: black;">MUA TIẾP</h1>
        </button></a>
                            <br><br><br><br><br>
                        </div>
                    </div>    
                </div>
    </div>
</body>
</html>

    

